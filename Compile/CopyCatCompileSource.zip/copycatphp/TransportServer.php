<?php

include_once 'MicrotecPHPUtils/utils/Object.php';
require_once 'MicrotecPHPUtils/db/Connection.php';


class DateField {
	public $value;
/*	public function __toString() {
		return "'" . date("Y-m-d", $value) . "'";
  		error_log("XMLRPCTransportServer.php line 97 : date value : " . date("Y-m-d", $d) . " ($d->value) ", 1, "jn@microtec.fr");
	}*/
}

class Session implements Serializable{
	public $connection;
	public $sessionID;
	public $clientCopyCatVersion;
	public $lastActivity;
	public $ReplicatingNode;

	public function __construct($ASessionID, $AConnection){
		//one unique connection for each session, against the same database.
		$this->connection = new Connection();
		$this->connection->DBType = $AConnection->DBType;
		$this->connection->DBVersion = $AConnection->DBVersion;
		$this->connection->DBName = $AConnection->DBName;
		$this->connection->DriverName = $AConnection->DriverName;
		$this->connection->Password = $AConnection->Password;
		$this->connection->UserName = $AConnection->UserName;
		$this->sessionID = $ASessionID;
	}
	public function serialize()
	{
		return serialize(array($this->sessionID, $this->clientCopyCatVersion, $this->lastActivity, $this->connection, $this->ReplicatingNode));
	}

	public function unserialize($serialized)
	{
		list($this->sessionID, $this->clientCopyCatVersion, $this->lastActivity, $this->connection, $this->ReplicatingNode) = unserialize($serialized);
	}
}

abstract class TransportServer extends Object {
	private $VersionNumber = "2.03.0 PHP";
	private $cleanupTimer;
	private $sessionTimeout=2; //Session timeout in minutes

	public $Password;
	public $databaseAlias;
	public $connection;

	private $RemoteFunction = array("funcConnNewQuery"=>0, "funcSetProperty"=>1, "funcConnDisconnect"=>2, "funcConnConnect"=>3, "funcConnCommit"=>4, "funcConnCommitRetaining"=>5, "funcConnRollback"=>6, "funcConnRollbackRetaining"=>7, "funcConnStartTransaction"=>8, "funcQryExec"=>9, "funcQryPrepare"=>10, "funcQryUnPrepare"=>11, "funcQryClose"=>12, "funcQryFetch"=>13, "funcQrySetParam"=>14, "funcQryParamCheck"=>15, "funcKeepAlive"=>16);

	public function __construct()
	{
		parent::__construct();
	}

	public function __destruct()
	{

	}

	/*private function Fetch($conn, $QueryID, &$Result) {
		$Result = array();
		$qry = $conn->getQuery($QueryID);
		if (!$qry->Eof) {
			for ($i = 0; $i < $qry->FieldCount; $i++){
				$field = $qry->FieldByIndex($i);
				$fieldValue = array($field->FieldName, $field->Value);
				$Result[] = $fieldValue;
			}
			$qry->Next();
		}
	}*/

	private function Exec($conn, $QueryID, $SQLParams, &$Result, $ReplicatingNode) {
		//Apply ReplicatingNode to database
		//This is MySQL-specific...

		$q = new Query($conn);
		$q->SQL = "set @COPYCAT_REPLICATING_NODE = '$ReplicatingNode'";
		$q->Exec();

		$qry = $conn->getQuery(strval($QueryID));
		$qry->Close();
		$NeedFieldDefs = false;
		if (isset($SQLParams)) {
			$NeedFieldDefs = ($SQLParams[0] == "Y");
			foreach ($SQLParams as $i => $param) {
				//Skip first parameter, because it holds the "Need field defs" flag
				if ($i > 0) {
					$qry->ParamByIndex($i-1)->Value = $SQLParams[$i];
				}
			}
		}
		$qry->Exec();

		$Result[] = $qry->RowsAffected;

		if ($qry->FieldCount > 0) {
			$records = array();
			while (!$qry->Eof) {
				$fieldValues = array();
				foreach ($qry->Fields as $field) {
					if (($field->DataType == "DATETIME") || ($field->DataType == "DATE") || ($field->DataType == "TIME")){
						$d = new DateField(); 
						$d->value = strtotime($field->Value);
						$fieldValues[] = $d;
						//error_log("TransportServer.php line 109 : date value : $d->value", 1, "jn@microtec.fr");
					}
					else {
						$fieldValues[] = $field->Value;
					}
				}
				$records[] = $fieldValues;
				$qry->Next();
			}
			$Result[] = $records;
		}

		//Send back field definitions if needed
		if ($NeedFieldDefs) {
			$fieldDefs = array();
			foreach ($qry->Fields as $field) {
				$size = 0;
				if ($field->DataType == "STRING") {
					$size = $field->Size;
				}

				$fieldDef = array($field->FieldName, $field->DataType, $size);
				$fieldDefs[] = $fieldDef;
			}
			$Result[] = $fieldDefs;
		}
	}

	private function Prepare($conn, $QueryID, $SQLText, $lQryParamCheck, &$Result) {
		$qry = $conn->getQuery(strval($QueryID));
		$qry->SQL = $SQLText;
		$qry->ParamCheck = $lQryParamCheck;
		$qry->Prepare();
		$paramDefs = array();
		foreach ($qry->Params as $param) {
			$paramDef = array($param->FieldName, 'UNKNOWN', 0);
			$paramDefs[] = $paramDef;
		}
		$Result[] = $paramDefs;
	}

	private function checkReplicationPassword($session) {
		if ($session->ReplicatingNode != '') {
			$q = new Query($session->connection);
			$q->SQL = "select passwrd from RPL\$USERS where login = '$session->ReplicatingNode'";
			$q->Exec();
			if ($q->RecordCount == 0)
				throw new Exception("Replication node $session->ReplicatingNode not found!");
			if ($q->Field("passwrd")->Value != $session->ReplicationPassword)
				throw new Exception("Wrong password $session->ReplicationPassword for node $session->ReplicatingNode!");
		}
	}

	private function checkParamCount($params, $functionName, $paramCount) {
		if (!isset($params) || (count($params) != $paramCount))
      throw new Exception("Invalid parameters for call to function " . $functionName . "!");
	}

	private function DoExecuteFunction(&$session, $objectID, $functionName, $params, &$result) {
		switch ($functionName) {

			case "funcKeepAlive":
				//Nothing to do here, just calling the function is enough to keep the session alive.
				break;

			case "funcConnDisconnect":
				$session->connection->Close();
				session_destroy();
				break;

			case "funcConnConnect":
				$session->ReplicatingNode = $params[0];
				$session->ReplicationPassword = $params[1];
				$session->connection->Open();
				$this->checkReplicationPassword($session);
				break;

			//
			case "funcConnCommit":
			case "funcConnCommitRetaining":
			case "funcConnRollback":
			case "funcConnRollbackRetaining":
				break;

			//The transaction is automatically started upon opening the connection
			case "funcConnStartTransaction": break;

			case "funcQryExec":
				//Execute and return the field list
				$this->Exec($session->connection, $objectID, $params, $result, $session->ReplicatingNode);
				break;

			case "funcQryPrepare":
				//Prepare and return the param list
				$this->checkParamCount($params, $functionName, 2);
				$this->Prepare($session->connection, $objectID, strval($params[0]), $params[1], $result);
				break;

			case "funcQryUnPrepare":
				$session->connection->getQuery(strval($objectID))->UnPrepare();
				break;

			//These functions are obselete
			case "funcConnNewQuery":
			case "funcQryFetch":
			case "funcQryClose":
			case "funcQrySetParam":
			case "funcQryParamCheck":
				break;

			default:
				throw new Exception("Invalid remote function " . $functionName . "!");
		}
	}

	protected function ExecuteFunction($Params, &$Result) {
		$sessionID = $Params[0];
		session_id($sessionID);
		session_start();
		if (!isset($_SESSION['COPYCAT_CURRENT_SESSION'])) {
			$Result[] = "ERROR:NOT_LOGGED_IN";
			session_destroy();
			return;
		}
		//Return the connection ID to the client, so that the same session can be used again
		$Result[] = $sessionID;

		$session = $this->getSession();
		$session->lastActivity = time();

		//Execute the function, and return the result as the second element of the result array
		$results = array();
		$functionParams = null;
		if (count($Params) >= 4) {
			$o = $Params[3];
			if (is_array($o)){
				$functionParams = $o;
			}
			else {
				$functionParams = array($o);
			}
		}
		$this->DoExecuteFunction($session, $Params[1], array_search($Params[2], $this->RemoteFunction), $functionParams, $results);

		//We have to commit the transaction after every request, because the PDO connection can't be stored
		//In effect, we are therefore auto-committing everything and cannot work with transactions
		$session->connection->Commit();

		session_write_close();
        //Return the results to the client
        $Result[] = $results;
	}

	private function getSession()
	{
		//Fetch the session from the global session list
		return $_SESSION['COPYCAT_CURRENT_SESSION'];
	}

	private function addSession($session)
	{
		//Add a session to the global session list
		$_SESSION['COPYCAT_CURRENT_SESSION'] = $session;
	}

	protected function DoLogin($params, &$result) {
		if (count($params) != 2) {
			throw new Exception("Invalid parameters for call to Login");
		}
		$cPassword = $params[1];
		if ($cPassword != $this->Password) {
			throw new Exception("Incorrect password for accessing this database connection : $cPassword");
		}

		//Create a new session
		session_start();
		session_regenerate_id();
		$sessionID = session_id();

		$session = new Session($sessionID, $this->connection);
		$session->clientCopyCatVersion = $params[0];
		$this->addSession($session);

		$result[] = $sessionID;
		$result[] = $this->connection->DBType;
		$result[] = $this->connection->DBVersion;
		$result[] = $this->connection->DBName;
		$result[] = $this->VersionNumber;
	}

	/*private function cleanupSessions(){
		foreach ($GLOBALS['COPYCAT_XMLRPC_SESSIONS'] as $session) {
			if ((time() - $session->lastActivity) > ($this->sessionTimeout * 60000)) {
				//Session expired
 				$this->closeSession($session);
			}
		}
	}

	private function closeSession($session){
		if (isset($session->connection)) {
			if ($session->connection->Connected) {
				try {
					$session->connection->Rollback();
					$session->connection->Close();
				} catch (Exception $e) {
					$e->getTraceAsString();
				}
			}
		}
		$this->removeSession($session->sessionID);
	}*/

}