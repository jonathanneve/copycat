<?php

$include_path = get_include_path();

//Adjust the include path to provide access to CopyCat libraries
//set_include_path($include_path . ':/copycat/');

require_once ('xmlrpc/XmlRpcTransportServer.php');
require_once ('xmlrpc/IXR_Library.inc.php');
require_once ('MicrotecPHPUtils/db/Connection.php');
require_once ('MicrotecPHPUtils/db/lib/drivers/adodb-mysql.inc.php');


function exception_handler($exception) {
  $str = "[" . date("Y/m/d h:i:s", mktime()) . "] " . $exception->getMessage() . "\n";	
	error_log($msg, 3, "/errors.log");
	throw $exception;
}

set_exception_handler('exception_handler');

$conn = new Connection();
$conn->DBType = "MySQL";
$conn->DBVersion = "5.0";
$conn->DBName = "localhost/copycat";
$conn->UserName = "root";
$conn->Password = "";

$xmlrpc = new XmlRpcTransportServer();
$xmlrpc->connection = $conn;
$xmlrpc->databaseAlias = "COPYCAT";
$xmlrpc->Password = "";

$server = new IXR_Server($xmlrpc->getDeclaredMethods());

?>
