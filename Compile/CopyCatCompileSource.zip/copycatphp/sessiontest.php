<?php
//$s = session_id(0);
		session_start();
		$session = session_regenerate_id();
		$s = session_id();
?>