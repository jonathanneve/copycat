<?php
 print (phpinfo());
?>