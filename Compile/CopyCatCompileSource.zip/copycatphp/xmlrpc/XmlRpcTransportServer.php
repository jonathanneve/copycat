<?php

require_once 'TransportServer.php';

class XmlRpcTransportServer extends TransportServer {

	//private final Base64 base64Codec = new Base64();

	public function getRpcPackageName(){
		return "copycat." . $this->databaseAlias;
	}

    public function getDeclaredMethods() {
    	$methods = array();
    	$methods["copycat.$this->databaseAlias.RemoteCall"] = array($this, "this:RemoteCall");
		$methods["copycat.$this->databaseAlias.Login"] = array($this, "this:Login");
		return $methods;

    	/*$methods = array();
    	$methods["copycat.$this->databaseAlias.RemoteCall"] = array(
			"function" => "RemoteCall",
			"signature" => array(array($GLOBALS['xmlrpcArray'], $GLOBALS['xmlrpcArray']))
		    );
    	$methods["copycat.$this->databaseAlias.Login"] = array(
			"function" => "Login",
			"signature" => array(array($GLOBALS['xmlrpcArray'], $GLOBALS['xmlrpcArray']))
		    );
    	return $methods;*/
    }

	/**
	* @param array $params Remote call parameters
	* @return array Remote call return value
	*/
	public function RemoteCall($params)
	{
		$result = array();

		$params = $this->convertFromXMLDatatypes($params);

		//Execute the function
		$this->ExecuteFunction($params, $result);

		$result = $this->convertToXMLDatatypes($result);

		//Return the results to the client
		return $result;
	}

	/**
	* @param array $params Login parameters
	* @return array Login return value
	*/
	public function Login($params)
	{
		$result = array();
		$params = $this->convertFromXMLDatatypes($params);

		//Execute the function
		$this->DoLogin($params, $result);

		$result = $this->convertToXMLDatatypes($result);

		//Return the results to the client
		return $result;
	}

	private function convertToXMLDatatypes($v) {
		foreach ($v as $i => $o){
			if (!isset($o)) {
				$v[$i] = "!!!XML-RPC-NULL!!!";
			}
			if (is_string($o)) {
				$v[$i] = base64_encode($o);
			}
			else if (is_long($o)) {
				$v[$i] = intval($o);
			}
			else if (is_array($o)) {
				$v[$i] = $this->convertToXMLDatatypes($o);
			}
			else if ($o instanceof DateField) {
				if ($o->value == 0) {
					$v[$i] = "!!!XML-RPC-NULL!!!";
				}
				else {
					$d = new IXR_Date(date("Ymd", $o->value) . "T" .date("H:i:s", $o->value));
					$v[$i] = $d;
					//error_log("XMLRPCTransportServer.php line 84 : date value : " . date("Y-m-d", $o->value) . " ($o->value) ", 1, "jn@microtec.fr");
				}
			}
		}
		return $v;
	}

	private function convertFromXMLDatatypes($v) {
		foreach ($v as $i => $o){
			if ($o instanceof IXR_Date) {
				/*$d =  new DateField();
				$d->value = $o->getTimestamp();
				$v[$i] = $d;
				error_log("XMLRPCTransportServer.php line 97 : date value : " . date("Y-m-d", $d) . " ($d->value) ", 1, "jn@microtec.fr");*/
			}
		  	else if (is_string($o)) {
				if (trim($o) == "!!!XML-RPC-NULL!!!") {
					$o = null;
				}
				else {
					$o = base64_decode($o);
					if ($o == "!!!XML-RPC-NULL-STRING!!!") {
						$o = "";
					}
				}				
				$v[$i] = $o;

				//Decode the UTF-8 data into a Java string
				//v.setElementAt(/*Charset.forName("UTF-8").decode(bb).toString()*/ bb.asCharBuffer().toString(), i);
			}
			else if (is_array($o)) {
			        //error_log("Is array!", 0);
				$v[$i] = $this->convertFromXMLDatatypes($o);
			}
		}
		return $v;
	}
}