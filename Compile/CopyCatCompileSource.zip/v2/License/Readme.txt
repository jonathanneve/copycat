COPYCAT V3 Readme
Copyright(c) 2011 by Microtec Communications -- All rights reserved.
http://www.microtec.fr/copycat

Thank you for trying our COPYCAT components!

LICENCE
~~~~~~~

See the Licence.txt that came with this package for all the do's and don't's.
If you don't speak legalese or it if bores you, this is what it says in a 
nutshell: 

1) You aren't allowed to sell, give, rent or lend this software to anyone.

2) Since this is a trial version, you're only allowed to use it to evaluate
the software -- you can't actually use it for any real work without paying
us for it. 

3) We aren't liable for anything that goes wrong because of using or misusing 
this software,

