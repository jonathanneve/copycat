COPYCAT V3 Readme
Copyright(c) 2011 by Microtec Communications -- All rights reserved.
http://www.microtec.fr/copycat

Thank you for buying our COPYCAT components!

LICENCE
~~~~~~~

See the Licence.txt that came with this package for all the do's and don't's.
If you don't speak legalese or it if bores you, this is what it says in a 
nutshell: 

1) You aren't allowed to sell, give, rent or lend this software to anyone.

2) You have been granted a nominative license for using these components
(with or without source code). You are of course strictly prohibited from 
distributing the download links, license keys, or passwords you received upon 
registration. Any leakages will lead us to the user who leaked -- not a good 
thing for that user!

3) We aren't liable for anything that goes wrong because of using or misusing 
this software.

