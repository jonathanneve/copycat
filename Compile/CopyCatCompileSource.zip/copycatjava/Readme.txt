Microtec CopyCat Java XMLRPC server implementation
Version 2.02.0
Copyright 2007 -- All rights reserved
***************************************************************************************

This package contains a Java XMLRPC transport server implementation for CopyCat, which allows you to replicate your databases using the Delphi CopyCat components, over XMLRPC, through a Java server.

How to use:

1) Unpack this archive, keeping the directory structure.

2) Edit test.CopyCatServer.java, to setup the connection(s) to your database(s).

3a) Run test.CopyCatServer. This is a fully-functional XMLRPC server with an embedded HTTP server. By default it runs on port 8080, but you can change that in test.CopyCatServer.java.

OR

3b) Edit test.CopyCatServer.java, to integrate it into an application server, such as Tomcat.

4) Make a Delphi client application using the CopyCat components. Use a TCcXmlRpcClientTransport to connect to your Java XMLRPC server, and set the DatabaseAlias to one of the connections that you set up in step 2.

5) Replicate in peace! :)

If you need help using this package, please let us know by asking your questions on our CopyCat forum at: http://www.microtec.fr/copycat/forums. We'll probably publish better documentation with subsequent versions, but this should be enough to get you started.