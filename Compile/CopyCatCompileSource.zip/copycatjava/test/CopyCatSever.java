package test;

import org.apache.xmlrpc.WebServer;
import org.apache.xmlrpc.XmlRpc;
import fr.microtec.db.Connection;
import copycat.xmlrpc.XmlRpcTransportServer;

public class CopyCatSever {

	public static void main (String[] args) throws ClassNotFoundException {
		try {
			Class.forName("org.firebirdsql.jdbc.FBDriver").newInstance();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		XmlRpc.setDriver(Class.forName("uk.co.wilson.xml.MinML"));
		WebServer web = new WebServer(8080);

		Connection conn = new Connection();
		conn.setDbName("jdbc:firebirdsql:localhost/3052:c:\\projects\\copycat\\test\\data\\TEST_DIALECT1.FDB");
		conn.setUserName("SYSDBA");
		conn.setPassword("masterkey");
		conn.setDBType("Interbase");
		conn.setDBVersion("FB1.5");
		
		XmlRpcTransportServer xml = new XmlRpcTransportServer();
		xml.setConnection(conn);
		xml.setDatabaseAlias("COPYCAT_LOCAL");
		xml.Password = "microtec";
		web.addHandler(xml.getRpcPackageName(), xml);

		Connection connRemote = new Connection();
		connRemote.setDbName("jdbc:firebirdsql:localhost/3052:c:\\projects\\copycat\\test\\data\\TEST_DIALECT1_REMOTE.FDB");
		connRemote.setUserName("SYSDBA");
		connRemote.setPassword("masterkey");
		connRemote.setDBType("Interbase");
		connRemote.setDBVersion("FB1.5");
		XmlRpcTransportServer xmlRemote = new XmlRpcTransportServer();
		xmlRemote.setConnection(connRemote);
		xmlRemote.setDatabaseAlias("COPYCAT_REMOTE");
		xmlRemote.Password = "microtec";
		web.addHandler(xmlRemote.getRpcPackageName(), xmlRemote);

		Connection connPenngar = new Connection();
		connPenngar.setDbName("jdbc:firebirdsql:192.168.2.100/3050:/opt/firebird/data/france.fdb");
		connPenngar.setUserName("SYSDBA");
		connPenngar.setPassword("masterkey");
		connPenngar.setDBType("Interbase");
		connPenngar.setDBVersion("FB1.5");
		XmlRpcTransportServer xmlPenngar = new XmlRpcTransportServer();
		xmlPenngar.setConnection(connPenngar);
		xmlPenngar.setDatabaseAlias("PENNGAR");
		xmlPenngar.Password = "microtec";
		web.addHandler(xmlPenngar.getRpcPackageName(), xmlPenngar);

		web.start();		
	}
}
