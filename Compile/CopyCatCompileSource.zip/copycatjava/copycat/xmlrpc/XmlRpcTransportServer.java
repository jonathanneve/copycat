package copycat.xmlrpc;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.sql.SQLException;
import java.util.Vector;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.EncoderException;
import org.apache.commons.codec.binary.Base64;

import copycat.TransportServer;
import copycat.TransportServer.RpcWrongPasswordException;
import fr.microtec.db.QueryException;

/**
 * @author Jonathan Neve
 * copycat.xmlrpc.XmlRpcTransportServer.RemoteCall(java.lang.String, java.lang.String, int, java.util.Vector)
 */
public class XmlRpcTransportServer extends TransportServer {

	private final Base64 base64Codec = new Base64();
	
	public String getRpcPackageName(){
		return "copycat." + getDatabaseAlias();
	}
	public Vector RemoteCall(Vector params) throws RpcWrongParamsException, RpcNoSuchFunctionException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, QueryException, UnsupportedEncodingException, EncoderException, DecoderException
	{
		Vector result = new Vector();

		convertFromXMLDatatypes(params);
		
		//Execute the function
		ExecuteFunction(params, result);

		convertToXMLDatatypes(result);

		//Return the results to the client
		return result;
	}
	
	public Vector Login(Vector params) throws RpcWrongParamsException, RpcNoSuchFunctionException, InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, QueryException, UnsupportedEncodingException, EncoderException, DecoderException, RpcWrongPasswordException
	{
		Vector result = new Vector();
		convertFromXMLDatatypes(params);
		
		//Execute the function
		DoLogin(params, result);

		convertToXMLDatatypes(result);

		//Return the results to the client
		return result;
	}

	private void convertToXMLDatatypes(Vector v) throws UnsupportedEncodingException, EncoderException{
		for (int i = 0; i < v.size(); i++){
			Object o = v.elementAt(i);
						
			if (o == null) {
				v.setElementAt("!!!XML-RPC-NULL!!!", i);
			}
			if (o instanceof String) {
				//Encode the string as UTF-8
				String s = o.toString();
				if (s.equals(""))
					s = "!!!XML-RPC-NULL-STRING!!!";
				byte[] b = s.getBytes();//java.nio.charset.Charset.forName("UTF-8").encode(o.toString()).array();
				
				b = base64Codec.encode(b);
				
				//Encode the bytes as base64 binary, and send them as a string
				v.setElementAt(new String(b), i);				
//				v.setElementAt(ByteBuffer.wrap(base64Codec.encode(b)).asCharBuffer().toString(), i);				
				//v.setElementAt(o.toString().getBytes("UTF-8"), i);
			}
			else if (o instanceof Long) {
				Long l = (Long)o;
				v.setElementAt(l.intValue(), i);
			}
			else if (o instanceof Vector) {
				convertToXMLDatatypes((Vector)o);
			}
			
//			if (o.equals("!!!XML-RPC-NULL!!!"))
//				v.setElementAt("", i);
//			else if (o.equals(""))
//				v.setElementAt("!!!XML-RPC-NULL!!!", i);
		}
	}
	private void convertFromXMLDatatypes(Vector v) throws DecoderException{
		for (int i = 0; i < v.size(); i++){
			Object o = v.elementAt(i);
			if (o instanceof String) {
				String s = o.toString();
				if (s.equals("!!!XML-RPC-NULL-STRING!!!"))
					s = "";
				else if (s.equals("!!!XML-RPC-NULL!!!"))
					s = null;
				else {	
					//Decode the base64 string
					byte[] b = base64Codec.decode(o.toString().getBytes());
					//Convert the byte array into a string
					StringBuffer sb = new StringBuffer("");
					for (int j = 0; j < b.length; j++) {
						sb.append((char)b[j]);
					}
					s = sb.toString();
				}

				v.setElementAt(s, i);				
				
				//Decode the UTF-8 data into a Java string
				//v.setElementAt(/*Charset.forName("UTF-8").decode(bb).toString()*/ bb.asCharBuffer().toString(), i);
			}
			else if (o instanceof Vector) {
				convertFromXMLDatatypes((Vector)o);
			}

//			if (o.equals("!!!XML-RPC-NULL!!!"))
//				v.setElementAt("", i);
//			else if (o.equals(""))
//				v.setElementAt("!!!XML-RPC-NULL!!!", i);
		}
	}
}
