/*
 * TransportServer.java
 *
 * Created on 12 juillet 2006, 16:43
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package copycat;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Vector;

import fr.microtec.db.Connection;
import fr.microtec.db.Field;
import fr.microtec.db.Param;
import fr.microtec.db.Query;
import fr.microtec.db.QueryException;

public abstract class TransportServer {
	public final String VersionNumber = "2.01.0 Java";
	//private int counter = 0;
	private CleanupTimer cleanupTimer;
//    private final java.util.HashMap<String, Connection> connections = new java.util.HashMap<String, Connection>(); 
	private int sessionTimeout=2; //Session timeout in minutes	
	private HashMap<String, Session> sessions = new HashMap<String, Session>(); 
    public String Password;
    private String databaseAlias;
    private Connection connection;

	private enum RemoteFunction {
    	funcConnNewQuery, funcSetProperty, funcConnDisconnect, funcConnConnect, funcConnCommit,
    	  funcConnCommitRetaining, funcConnRollback, funcConnRollbackRetaining, funcConnStartTransaction,
    	  funcQryExec, funcQryPrepare, funcQryUnPrepare, funcQryClose, funcQryFetch, funcQrySetParam, funcQryParamCheck, funcKeepAlive        
	}
	public class RpcException extends Exception {
    	public RpcException(String message){
    		super(message);
    	}
    }
	public class RpcWrongParamsException extends RpcException {
		public RpcWrongParamsException(String message) {
			super(message);
		}
    }
	public class RpcNoSuchFunctionException extends RpcException {
		public RpcNoSuchFunctionException(String message) {
			super(message);
		}
    }
	public class RpcWrongPasswordException extends RpcException {
		public RpcWrongPasswordException(String message) {
			super(message);
		}
    }	
		    
    private class CleanupTimer
        implements Runnable
    {

        private TransportServer transportServer;
        private int frequency;
        private boolean enabled;
        private Thread cleaner;
        
		public void start()
        {
            enabled = true;
            cleaner = new Thread(this);
            cleaner.setDaemon(true);
            cleaner.setPriority(5);
            cleaner.start();
        }

        public void stop()
        {
            enabled = false;
        }

        public void run()
        {
            while(enabled) 
                try
                {
                    transportServer.cleanupSessions();
                    //Thread _tmp = cleaner;
                    Thread.sleep(frequency);
                }
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }
        }

        public CleanupTimer(TransportServer ts, int frequency)
        {            
            enabled = false;
            transportServer = ts;
            this.frequency = frequency;
        }
    }

	private class Session {
		private Connection connection;
		public final String sessionID;
		public String clientCopyCatVersion;
		private long lastActivity;
		
		private Session(String ASessionID, Connection AConnection){
			//one unique connection for each session, against the same datbase.
            connection = new Connection();
            connection.setDBType(AConnection.getDBType());
            connection.setDBVersion(AConnection.getDBVersion());
            connection.setDbName(AConnection.getDbName());
            connection.setDriverName(AConnection.getDriverName());
            connection.setPassword(AConnection.getPassword());
            connection.setUserName(AConnection.getUserName());
            sessionID = ASessionID;
   		}				
	}

    public TransportServer()
    {
        cleanupTimer = new CleanupTimer(this, 30000);
        cleanupTimer.start();
    }

    public void destroy()
    {
        cleanupTimer.stop();
    }

    private void Fetch(Connection conn, int QueryID, Vector Result) throws QueryException, SQLException {
    	Query qry = conn.getQuery(String.valueOf(QueryID));
    	if (!qry.isEof()) {
    		for (int i = 0; i < qry.getFieldCount(); i++){
    			Vector fieldValue = new Vector(2);
    			Field f = qry.getFieldByIndex(i);
    			fieldValue.add(f.getFieldName());
    			fieldValue.add(f.getValue());
    			Result.add(fieldValue);
    		}
    		qry.next();
    	}
    }
    
    private void Exec(Connection conn, int QueryID, Vector SQLParams, Vector Result) throws QueryException, SQLException {
    	Query qry = conn.getQuery(String.valueOf(QueryID));
    	qry.close();
    	if (SQLParams != null) {
    		for (int i=1; i<SQLParams.size(); i++)
    			qry.getParamByIndex(i-1).setValue(SQLParams.elementAt(i));
    	}
    	qry.exec();
  
    	Result.add(qry.getRowsAffected());
    	
    	if (qry.getFieldCount() > 0) {
    		Vector records = new Vector();
    		while (!qry.isEof()) {
        		Vector fieldValues = new Vector();
    			for (int i=0; i<qry.getFieldCount(); i++) {
    				fieldValues.add(qry.getFieldByIndex(i).getValue());
    			}
    			records.add(fieldValues);
    			qry.next();
    		}
			Result.add(records);
    	}
		    
    	//Send back field definitions if needed
    	if (SQLParams.get(0).equals("Y")) {//Need field defs? (Y/N)
        	Vector fieldDefs = new Vector();
    		for (int i = 0; i < qry.getFieldCount(); i++) {
    			Field currField = qry.getFieldByIndex(i);
    			Vector fieldDef = new Vector(3);
    			fieldDef.add(currField.getFieldName());
    			fieldDef.add(currField.getDataType().toString());
                int nSize = 0;
                if(currField.getDataType().toString() == "STRING")
                    nSize = currField.getSize();
    			fieldDef.add(nSize);
    			fieldDefs.add(fieldDef);
    		}
    		Result.add(fieldDefs);
    	}	
    }
    
    private void Prepare(Connection conn, int QueryID, String SQLText, boolean lQryParamCheck, Vector Result) throws SQLException, QueryException {
    	Query qry = conn.getQuery(String.valueOf(QueryID));
    	qry.setSQL(SQLText);
    	qry.setParamCheck(lQryParamCheck);
    	qry.prepare();
        Vector paramDefs = new Vector();
    	for (int i = 0; i < qry.getParamCount(); i++) {
    		Param currParam = qry.getParamByIndex(i);
    		Vector paramDef = new Vector(3);
    		paramDef.add(currParam.getFieldName());
    		paramDef.add(currParam.getDataType().toString());
    		paramDef.add(currParam.getSize());
    		paramDefs.add(paramDef);
    	}    	 
    	Result.add(paramDefs);
    }
    
	private void checkParamCount(Vector params, RemoteFunction functionName, int paramCount) throws RpcWrongParamsException{
		if ((params == null) || (params.size() != paramCount))
	      throw new RpcWrongParamsException("Invalid parameters for call to function " + functionName.toString() + "!");
	}

	private void DoExecuteFunction(Session session, int objectID, RemoteFunction functionName, Vector params, Vector result) throws RpcWrongParamsException, SQLException, QueryException, RpcNoSuchFunctionException {
		switch (functionName) {

		case funcConnNewQuery:
			session.connection.getQuery(String.valueOf(objectID));
			break;
		
		case funcKeepAlive:
			//Nothing to do here, just calling the function is enough to keep the session alive.
			break;

		case funcConnDisconnect:
            closeSession(session);
			break;

		case funcConnConnect:
			session.connection.open();
			break;

		case funcConnCommit:
			session.connection.commit();
			break;

		case funcConnCommitRetaining:
			session.connection.commitRetaining();
			break;

		case funcConnRollback:
			session.connection.rollback();
			break;

		case funcConnRollbackRetaining:
			session.connection.rollbackRetaining();
			break;

			//The transaction is automatically started upon opening the JDBC connection
		case funcConnStartTransaction: break;

		case funcQryExec:
			//Execute and return the field list
			Exec(session.connection, objectID, params, result);
			break;

		case funcQryFetch:
			Fetch(session.connection, objectID, result);
			break;

		case funcQryPrepare: 
			//Prepare and return the param list
			checkParamCount(params, functionName, 2);
			Prepare(session.connection, objectID, params.elementAt(0).toString(), (Boolean)params.elementAt(1), result);
			break;

		case funcQryClose:
			session.connection.getQuery(String.valueOf(objectID)).close();
			break;

		case funcQryUnPrepare:
			session.connection.getQuery(String.valueOf(objectID)).unPrepare();
			break;

		case funcQrySetParam: 
			checkParamCount(params, functionName, 2);
			session.connection.getQuery(String.valueOf(objectID)).getParam(params.elementAt(0).toString()).setValue(params.elementAt(1));   	    
			break;

		case funcQryParamCheck: 
			checkParamCount(params, functionName, 1);
			session.connection.getQuery(String.valueOf(objectID)).setParamCheck((Boolean)params.elementAt(0));
			break;

		default:
			throw new RpcNoSuchFunctionException("Invalid remote function " + functionName.toString() + "!");
		}
	}	
    
    protected void ExecuteFunction(Vector Params, Vector Result) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException, RpcWrongParamsException, RpcNoSuchFunctionException, QueryException{
    	String sessionID = Params.elementAt(0).toString();
    	Session session = getSession(sessionID);
    	if (session == null) {
    		Result.add("ERROR:NOT_LOGGED_IN");
    		return;
    	}
  	
    	//Return the connection ID to the client, so that the same session can be used again
    	Result.add(sessionID);

    	session.lastActivity = System.currentTimeMillis();

    	//Execute the function, and return the result as the second element of the result array
    	Vector results = new Vector(); 
    	Vector functionParams = null;
    	if (Params.size() >= 4) {
    		Object o = Params.elementAt(3);
    		if (o instanceof Vector) 
    			functionParams = (Vector)o;
    		else {
    			functionParams = new Vector();
    			functionParams.add(o);
    		}
    	}
   		DoExecuteFunction(session, (Integer)Params.elementAt(1), RemoteFunction.values()[(Integer)Params.elementAt(2)], functionParams, results);
        Result.add(results);      
    }
        
	public Connection getConnection() {
		return connection;
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	public String getDatabaseAlias() {
		return databaseAlias;
	}

	public void setDatabaseAlias(String databaseAlias) {
		this.databaseAlias = databaseAlias;
	}

    private synchronized Session getSession(String sessionID)
    {
        return (Session)sessions.get(sessionID);
    }

    private synchronized void addSession(Session session, String sessionID)
    {
        sessions.put(sessionID, session);
    }

    private synchronized void removeSession(String sessionID)
    {
        sessions.remove(sessionID);
    }

	protected void DoLogin(Vector params, Vector result) throws RpcWrongParamsException, RpcWrongPasswordException{
		if (params.size() != 2)
			throw new RpcWrongParamsException("Invalid parameters for call to Login");
		
        if(params.size() != 2)
            throw new RpcWrongParamsException("Invalid parameters for call to Login");
		String cPassword = params.get(1).toString();
		if (!cPassword.equals(Password))
			throw new RpcWrongPasswordException("Incorrect password for accessing this database connection");
		
		//Create a new session and add it to the session list
		String sessionID = java.util.UUID.randomUUID().toString();
		Session session = new Session(sessionID, connection);
		session.clientCopyCatVersion = params.get(0).toString();
		addSession(session, sessionID);
            
		result.add(sessionID);
		result.add(connection.getDBType());
		result.add(connection.getDBVersion());
		result.add(connection.getDBName());
		result.add(VersionNumber);		
	}

	public void cleanupSessions(){
		for (int i=sessions.size()-1; i>=0; i--) {
			Session session = sessions.get(i);
			if ((System.currentTimeMillis() - session.lastActivity) > (sessionTimeout * 60000))
				//Session expired
				closeSession(session);
		}		
	}
	
	private void closeSession(Session session){
		if (session.connection != null) {
			if (session.connection.getConnected()) {
				try {
					session.connection.rollback();
    				session.connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}		
        removeSession(session.sessionID);
	}
}
