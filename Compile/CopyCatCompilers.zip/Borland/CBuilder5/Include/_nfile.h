/*  _nfile.h

    Maximum number of open files

*/

/*
 *      C/C++ Run Time Library - Version 10.0
 *
 *      Copyright (c) 1991, 2000 by Inprise Corporation
 *      All Rights Reserved.
 *
 */

/* $Revision:   9.1  $ */

#ifndef ___NFILE_H
#define ___NFILE_H


#define _NFILE_ 50

#endif
