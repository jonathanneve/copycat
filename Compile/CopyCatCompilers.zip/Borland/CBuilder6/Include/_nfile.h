/*  _nfile.h

    Maximum number of open files

*/

/*
 *      C/C++ Run Time Library - Version 11.0
 *
 *      Copyright (c) 1991, 2002 by Borland Software Corporation
 *      All Rights Reserved.
 *
 */


/* $Revision: 9.5.2.2 $ */

#ifndef ___NFILE_H
#define ___NFILE_H


#define _NFILE_ 50

#endif
