#ifndef __VCL0_H__
#define __VCL0_H__
#pragma message Project should #include <basepch0.h> instead of <vcl0.h>
#include <basepch0.h>
#endif /* __VCL0_H__ */
